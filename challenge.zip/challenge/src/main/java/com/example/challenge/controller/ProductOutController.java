package com.example.challenge.controller;

import com.example.challenge.service.ProductService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/productsFromOut")
public class ProductOutController {

    private final ProductService produtoService;

    // Injeção do serviço no controlador
    public ProductOutController(ProductService produtoService) {
        this.produtoService = produtoService;
    }

    @GetMapping("/{id}")
    public ResponseEntity<Object> verificarProdutoExternoPorId(@PathVariable Long id) {
        try {
            // Usa o serviço para buscar o produto
            Object produto = produtoService.buscarProdutoExternoPorId(id);

            // Retorna o objeto do produto como JSON
            return ResponseEntity.ok(produto);

        } catch (RuntimeException e) {
            // Caso ocorra um erro
            return ResponseEntity.status(404).body("Produto não encontrado: " + e.getMessage());
        }
    }
}