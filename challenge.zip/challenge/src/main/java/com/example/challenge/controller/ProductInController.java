package com.example.challenge.controller;

import com.example.challenge.entity.Product;
import com.example.challenge.service.ProductService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/productsFromIn")
public class ProductInController {

    private final ProductService productService;

    // Injeta o serviço de produtos
    public ProductInController(ProductService productService) {
        this.productService = productService;
    }

    // Endpoint para salvar um novo produto
    @PostMapping
    public ResponseEntity<Product> salvarProduto(@RequestBody Product product) {
        try {
            Product produtoSalvo = productService.salvarProduto(product);
            return ResponseEntity.ok(produtoSalvo);

        } catch (Exception e) {
            return ResponseEntity.status(403).body(null); // Em caso de erro, retorna status 500
        }
    }

    // Endpoint para buscar um produto por ID
    @GetMapping("/{id}")
    public ResponseEntity<Object> buscarProdutoInternoPorId(@PathVariable Long id) {
        try {
            Object produto = productService.buscarProdutoInternoPorId(id);
            return ResponseEntity.ok(produto);

        } catch (RuntimeException e) {
            return ResponseEntity.status(404).body(null); // Caso não encontre, retorna status 404
        }
    }
}