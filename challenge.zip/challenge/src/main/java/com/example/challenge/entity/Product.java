package com.example.challenge.entity;

import jakarta.persistence.*;
import org.springframework.data.jpa.repository.Meta;

import java.math.BigDecimal;
import java.util.List;

@Table(name = "product")
@Entity
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String title;

    @Column(length = 1000)
    private String description;

    private String category;

    private BigDecimal price;

    @ElementCollection
    @CollectionTable(name = "product_tags", joinColumns = @JoinColumn(name = "product_id"))
    @Column(name = "tag")
    private List<String> tags;

    private String brand;

    private String sku;

    private Double weight;

    @Embedded
    private Dimensions dimensions;

    @Embedded
    private Meta meta;

    @ElementCollection
    @CollectionTable(name = "product_images", joinColumns = @JoinColumn(name = "product_id"))
    @Column(name = "image_url")
    private List<String> images;

    private String thumbnail;


}