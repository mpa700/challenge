package com.example.challenge.service;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RetryService {

    private static final int MAX_RETRIES = 6;

    @Autowired
    private ProductService productService;

    @RabbitListener(queues = "retryQueue")
    public void processarMensagem(Long id) {
        int attempt = 1;
        while (attempt <= MAX_RETRIES) {
            try {
                // Tentar buscar o produto novamente
                Object produto = productService.buscarProdutoInternoPorId(id);
                if (produto != null) {
                    // Caso seja bem-sucedido, saia do loop
                    return;
                }
            } catch (RuntimeException e) {
                // Se falhar, tentar novamente
                attempt++;
                if (attempt > MAX_RETRIES) {
                    // Caso atinja o número máximo de tentativas, logar ou tratar o erro
                    System.err.println("Falha ao processar o produto após " + MAX_RETRIES + " tentativas.");
                }
            }
        }
    }
}