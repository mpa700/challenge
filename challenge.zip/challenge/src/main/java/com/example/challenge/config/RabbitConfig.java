package com.example.challenge.config;

import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitConfig {

    // Define a fila
    @Bean
    public Queue retryQueue() {
        return new Queue("retryQueue", true);
    }

    // Define a troca (Exchange)
    @Bean
    public DirectExchange exchange() {
        return new DirectExchange("retryExchange");
    }

    // Define o binding entre fila e troca
    @Bean
    public Binding binding() {
        return BindingBuilder.bind(retryQueue()).to(exchange()).with("retryRoutingKey");
    }
}