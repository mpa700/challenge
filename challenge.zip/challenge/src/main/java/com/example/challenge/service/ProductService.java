package com.example.challenge.service;

import com.example.challenge.entity.Product;
import com.example.challenge.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import org.springframework.amqp.rabbit.core.RabbitTemplate;



@Service
public class ProductService {
    @Autowired
    private RabbitTemplate rabbitTemplate;
    private final ProductRepository repository;
    private final WebClient webClient;

    // Construtor que inicializa o WebClient
    @Autowired
    public ProductService(WebClient.Builder webClientBuilder, ProductRepository repository) {
        this.webClient = webClientBuilder.baseUrl("https://dummyjson.com/products").build();
        this.repository = repository;
    }

    public Product salvarProduto(Product product) {
        try{
            return repository.save(product);
        } catch (RuntimeException e) {
            rabbitTemplate.convertAndSend("retryExchange", "retryRoutingKey", product);
        }

        return product;
    }

    public Product buscarProdutoInternoPorId(Long id) {
        return repository.findById(id).orElseThrow(() -> new RuntimeException("Produto não encontrado"));
    }
    // Método para buscar um produto por ID
    public Object buscarProdutoExternoPorId(Long id) {
        try {
            // Faz a chamada GET para a API externa
            Mono<Object> produtoMono = webClient.get()
                    .uri("/{id}", id) // Substitui {id} pela variável id
                    .retrieve() // Executa a requisição
                    .bodyToMono(Object.class); // Converte a resposta para um objeto genérico

            // Aguarda o resultado da requisição sincronicamente
            return produtoMono.block();
        } catch (Exception e) {
            throw new RuntimeException("Erro ao buscar produto: " + e.getMessage(), e);
        }
    }
}