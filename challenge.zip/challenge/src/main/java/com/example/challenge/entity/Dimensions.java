package com.example.challenge.entity;
import jakarta.persistence.Embeddable;


@Embeddable
public class Dimensions {

    private Double width;
    private Double height;
    private Double depth;

}